import Link from 'next/link';
import Image from 'next/image';

interface ServiceCardProps {
  name: string;
  description: string;
  path: string;
  image: string;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ name, description, path, image }) => (
  <div className="service-card bg-white rounded-xl shadow-lg overflow-hidden border border-gray-100">
    <div className="relative h-48 w-full">
      <Image src={image} alt={name} fill style={{objectFit: 'cover'}} className="transition duration-500 group-hover:scale-105" />
    </div>
    <div className="p-6">
      <h4 className="text-xl font-bold text-gray-900 mb-2">{name}</h4>
      <p className="text-gray-600 mb-4 text-sm">{description}</p>
      <Link href={path} className="text-indigo-600 font-semibold hover:text-indigo-800 flex items-center">
        Learn More 
        <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 8l4 4m0 0l-4 4m4-4H3"></path></svg>
      </Link>
    </div>
  </div>
);

export default ServiceCard;