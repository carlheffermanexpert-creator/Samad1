import ServiceCard from './ServiceCard';

interface ServiceListProps {
  services: { id: number, name: string, description: string, path: string, image: string }[];
}

const ServiceList: React.FC<ServiceListProps> = ({ services }) => (
  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
    {services.map((service) => (
      <ServiceCard key={service.id} {...service} />
    ))}
  </div>
);

export default ServiceList;