import { useState } from 'react';
import { useRouter } from 'next/navigation';

interface FormData {
  name: string;
  email: string;
  serviceInterest: string;
  message: string;
}

const InquiryForm: React.FC = () => {
  const [formData, setFormData] = useState<FormData>({
    name: '',
    email: '',
    serviceInterest: 'Global Job Placement',
    message: '',
  });
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const router = useRouter();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const validate = (): boolean => {
    if (!formData.name || !formData.email || !formData.message) return false;
    if (!/\S+@\S+\.\S+/.test(formData.email)) return false;
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) {
      setStatus('error');
      return;
    }

    setStatus('submitting');
    try {
      const response = await fetch('/api/inquiry',
        { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(formData) }
      );

      if (response.ok) {
        setStatus('success');
        setFormData({ name: '', email: '', serviceInterest: 'Global Job Placement', message: '' });
        setTimeout(() => router.push('/'), 3000); // Redirect after success
      } else {
        const errorData = await response.json();
        setStatus('error');
        console.error('API Error:', errorData.message || 'Failed to submit inquiry.');
      }
    } catch (error) {
      setStatus('error');
      console.error('Network Error:', error);
    }
  };

  const renderStatusMessage = () => {
    switch (status) {
      case 'success':
        return <p className="text-green-600 font-semibold">Thank you! Your inquiry has been sent successfully. We will contact you shortly.</p>;
      case 'error':
        return <p className="text-red-600 font-semibold">Submission failed. Please check your details or try again later.</p>;
      case 'submitting':
        return <p className="text-indigo-600 font-semibold">Sending inquiry... Please wait.</p>;
      default:
        return null;
    }
  };

  return (
    <div className="max-w-3xl mx-auto bg-white p-8 rounded-xl shadow-2xl border border-indigo-100">
      <h3 className="text-3xl font-bold text-center text-gray-800 mb-2">Start Your Journey</h3>
      <p className="text-center text-gray-600 mb-8">Tell us about your goals, and our experts will guide you.</p>
      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-700">Full Name</label>
          <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-3 focus:ring-indigo-500 focus:border-indigo-500" />
        </div>
        <div>
          <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email Address</label>
          <input type="email" name="email" id="email" value={formData.email} onChange={handleChange} required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-3 focus:ring-indigo-500 focus:border-indigo-500" />
        </div>
        <div>
          <label htmlFor="serviceInterest" className="block text-sm font-medium text-gray-700">Area of Interest</label>
          <select name="serviceInterest" id="serviceInterest" value={formData.serviceInterest} onChange={handleChange} required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-3 focus:ring-indigo-500 focus:border-indigo-500 bg-white">
            <option value="Global Job Placement">Global Job Placement</option>
            <option value="Education Recruitment">Education Recruitment</option>
            <option value="Study Package">Study Package</option>
            <option value="Employer Services">Employer Services</option>
            <option value="Work Package">Work Package</option>
            <option value="Visa Assistance">Visa Assistance</option>
          </select>
        </div>
        <div>
          <label htmlFor="message" className="block text-sm font-medium text-gray-700">Your Message / Goals</label>
          <textarea name="message" id="message" rows={4} value={formData.message} onChange={handleChange} required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-3 focus:ring-indigo-500 focus:border-indigo-500"></textarea>
        </div>
        <button type="submit" disabled={status === 'submitting'} className="w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700 transition duration-150 disabled:bg-indigo-400 shadow-lg">
          {status === 'submitting' ? 'Sending...' : 'Submit Inquiry'}
        </button>
      </form>
      {renderStatusMessage()}
    </div>
  );
};

export default InquiryForm;