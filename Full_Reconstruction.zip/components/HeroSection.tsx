import Image from 'next/image';
import Link from 'next/link';

const HeroSection = () => (
  <div className="hero-bg h-[60vh] flex items-center justify-center text-center relative">
    {/* Image Overlay/Placeholder */}
    <div className="absolute inset-0 bg-black opacity-50"></div>
    
    <div className="relative z-10 p-6 max-w-4xl">
      <h1 className="text-6xl font-extrabold text-white mb-4 leading-tight">Connecting global talent to opportunity.</h1>
      <p className="text-xl text-gray-200 mb-8">Recruitment, education, travel and related support for people and organisations exploring plans across borders.</p>
      <Link href="/services" className="bg-indigo-600 text-white text-lg px-10 py-3 rounded-full hover:bg-indigo-700 transition duration-300 shadow-xl inline-block">Discover Services</Link>
    </div>
    {/* Image component placeholder based on analysis report */}
    <Image src="/images/editorial/candidate-hero.webp" alt="Candidate Hero" fill style={{objectFit: 'cover'}} className="absolute inset-0 opacity-30" />
  </div>
);

export default HeroSection;