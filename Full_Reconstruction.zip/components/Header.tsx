import Link from 'next/link';

const navItems = [
  { name: 'About', href: '/about' },
  { name: 'Services', href: '/services' },
  { name: 'Countries', href: '/countries' },
  { name: 'Contact', href: '/contact' },
];

const Header = () => (
  <header className="bg-white shadow-md sticky top-0 z-10">
    <div className="container mx-auto px-4 py-4 flex justify-between items-center">
      <Link href="/" className="text-2xl font-bold text-indigo-700">Nextabroad</Link>
      <nav className="hidden md:flex space-x-6">
        {navItems.map((item) => (
          <Link key={item.name} href={item.href} className="text-gray-600 hover:text-indigo-700 font-medium transition duration-150">{item.name}</Link>
        ))}
      </nav>
      <div className="hidden md:block">
        <Link href="/inquiry" className="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 transition duration-150 shadow-lg">Get Started</Link>
      </div>
      {/* Mobile Menu Button Placeholder */}
      <div className="md:hidden">
        <button className="text-gray-600 p-2 focus:outline-none"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7"></path></svg></button>
      </div>
    </div>
  </header>
);

export default Header;