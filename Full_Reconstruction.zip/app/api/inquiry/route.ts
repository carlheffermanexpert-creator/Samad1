import { NextResponse } from 'next/server';

// In a real application, this would connect to Prisma/DB
// For this simulation, we log the data and return success.

export async function POST(request: Request) {
  try {
    const body = await request.json();
    console.log("--- NEW INQUIRY RECEIVED ---");
    console.log("Name:", body.name);
    console.log("Email:", body.email);
    console.log("Service:", body.serviceInterest);
    console.log("Message:", body.message);
    console.log("----------------------------");

    // Simulate successful database write
    return NextResponse.json({ message: "Inquiry received successfully" }, { status: 200 });
  } catch (error) {
    console.error("Inquiry submission error:", error);
    return NextResponse.json({ message: "Invalid request payload or server error" }, { status: 400 });
  }
}
