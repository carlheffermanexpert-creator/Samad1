import './globals.css';
import { Inter } from 'next/font/google';

const inter = Inter({ subsets: ['latin'] });

export const metadata = {
  title: 'Nextabroad | Work, Study & International Services',
  description: 'Recruitment, education, travel and related support for people and organisations exploring plans across borders.',
  metadataBase: new URL('https://nextabroadinfo.com/'),
  openGraph: {
    title: 'Nextabroad | Work, Study & International Services',
    description: 'Recruitment, education, travel and related support for people and organisations exploring plans across borders.',
    siteName: 'Nextabroad',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Nextabroad | Work, Study & International Services',
    description: 'Recruitment, education, travel and related support for people and organisations exploring plans across borders.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={inter.className}>{children}</body>
    </html>
  );
}
