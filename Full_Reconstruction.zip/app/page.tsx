import Link from 'next/link';
import ServiceCard from '@/components/ServiceCard';
import Header from '@/components/Header';
import HeroSection from '@/components/HeroSection';
import ServiceList from '@/components/ServiceList';
import InquiryForm from '@/components/InquiryForm';

const services = [
  { id: 1, name: 'Global Job Placement', description: 'Recruitment support for international roles.', path: '/services/global-job-placement', image: '/images/editorial/global-job-placement-hero.webp' },
  { id: 2, name: 'Education Recruitment', description: 'Study abroad packages and university placement.', path: '/services/education-recruitment', image: '/images/editorial/education-recruitment-hero.webp' },
  { id: 3, name: 'Study Package', description: 'Comprehensive study abroad support.', path: '/services/study-package', image: '/images/editorial/study-package-hero.webp' },
  { id: 4, name: 'Employer Services', description: 'Partnerships for international talent acquisition.', path: '/services/employer', image: '/images/editorial/employer-hero.webp' },
  { id: 5, name: 'Work Package', description: 'Assistance with international employment visas.', path: '/services/work-package', image: '/images/editorial/work-package-editorial.webp' },
  { id: 6, name: 'Visa Assistance', description: 'Guidance through complex visa and immigration processes.', path: '/services/visa-assistance', image: '/images/editorial/visa-assistance-consultation.webp' },
];

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow">
        <HeroSection />
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-4xl font-bold mb-10">Explore our services</h2>
            <ServiceList services={services} />
          </div>
        </section>
        <section className="py-20 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Wherever you’re headed, start here.</h2>
            <InquiryForm />
          </div>
        </section>
      </main>
      <footer className="bg-gray-800 text-white p-8 text-center">
        <p>&copy; {new Date().getFullYear()} Nextabroad. All rights reserved. | <Link href="/contact" className="text-indigo-400">Contact Us</Link></p>
      </footer>
    </div>
  );
}
