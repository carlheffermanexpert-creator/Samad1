import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from '../api/api';
import jwtDecode from 'jwt-decode';

type User = {
  id: string;
  email: string;
};

type AuthContextType = {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);

  const loadUserFromToken = async (token: string | null) => {
    if (token) {
      try {
        const decoded: any = jwtDecode(token);
        setUser({ id: decoded.sub, email: decoded.email });
        axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      } catch {
        setUser(null);
      }
    } else {
      setUser(null);
    }
  };

  useEffect(() => {
    AsyncStorage.getItem('token').then(loadUserFromToken);
  }, []);

  const login = async (email: string, password: string) => {
    const response = await axios.post('/auth/login', { email, password });
    const token = response.data.token;
    await AsyncStorage.setItem('token', token);
    await loadUserFromToken(token);
  };

  const register = async (email: string, password: string) => {
    const response = await axios.post('/auth/register', { email, password });
    const token = response.data.token;
    await AsyncStorage.setItem('token', token);
    await loadUserFromToken(token);
  };

  const logout = async () => {
    await AsyncStorage.removeItem('token');
    setUser(null);
    delete axios.defaults.headers.common['Authorization'];
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
